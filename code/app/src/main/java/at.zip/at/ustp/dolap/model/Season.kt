package at.ustp.dolap.model

enum class Season(val label: String) {
    ALL("All"),
    SUMMER("Summer"),
    WINTER("Winter"),
    SPRING("Spring"),
    AUTUMN("Autumn")
}