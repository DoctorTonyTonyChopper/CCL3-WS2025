package at.ustp.dolap.model

val ClothingColors = listOf(
    "Black",
    "White",
    "Gray",
    "Blue",
    "Red",
    "Green",
    "Brown",
    "Beige"
)